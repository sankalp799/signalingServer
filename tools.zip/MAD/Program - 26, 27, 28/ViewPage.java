package com.lit.mad_pro;

import androidx.appcompat.app.AppCompatActivity;

import android.database.Cursor;
import android.os.Bundle;
import android.widget.TextView;

public class ViewPage extends AppCompatActivity {

    TextView Text;
    DatabaseHelper databaseHelper;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view_page);

        Text = findViewById(R.id.text);
        databaseHelper = new DatabaseHelper(ViewPage.this);
        String Data = "";
        Cursor cursor = databaseHelper.getAllData();
        while (cursor.moveToNext()){
            Data += "Id :- "+cursor.getString(0)+"\n{\n";
            Data += "\tName :- "+cursor.getString(1)+"\n";
            Data += "\tMobile Number :- "+cursor.getString(3)+"\n";
            Data += "\tCourse Name :- "+cursor.getString(2)+"\n}\n";
        }
        Text.setText(Data);
    }
}