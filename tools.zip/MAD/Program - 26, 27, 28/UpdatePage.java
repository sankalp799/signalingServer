package com.lit.mad_pro;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class UpdatePage extends AppCompatActivity {

    EditText Id, Name,Mobile,Course;
    Button Btn;
    DatabaseHelper databaseHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_update_page);


        Id = findViewById(R.id.id);
        Name = findViewById(R.id.name);
        Mobile = findViewById(R.id.mobile);
        Course = findViewById(R.id.course);

        Btn = findViewById(R.id.button);

        databaseHelper = new DatabaseHelper(UpdatePage.this);

        Btn.setOnClickListener(View->{
            int result = databaseHelper.updateData(Id.getText().toString(),Name.getText().toString(),Mobile.getText().toString(),Course.getText().toString());
            if (result == 0){
                Toast.makeText(getApplicationContext(), "Invalid Id!", Toast.LENGTH_SHORT).show();
            }else{
                Toast.makeText(getApplicationContext(), "Data Updated!", Toast.LENGTH_SHORT).show();
                finish();
            }
        });
    }
}