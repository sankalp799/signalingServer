package com.lit.mad_pro;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    TextView TV1,TV2,TV3,TV4;
    Button Btn;

    @SuppressLint("ResourceAsColor")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        TV1 = findViewById(R.id.text1);
        TV2 = findViewById(R.id.text2);
        TV3 = findViewById(R.id.text3);
        TV4 = findViewById(R.id.text4);

        Btn = findViewById(R.id.button);

        Btn.setOnClickListener(View->{
            TV1.setTextColor(getResources().getColor(R.color.col_1));
            TV2.setTextColor(getResources().getColor(R.color.col_2));
            TV3.setTextColor(getResources().getColor(R.color.col_3));
            TV4.setTextColor(getResources().getColor(R.color.col_4));
        });
    }
}