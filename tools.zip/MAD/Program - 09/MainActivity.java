package com.lit.mad_pro;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.MultiAutoCompleteTextView;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    EditText UName,Pass;
    Button Login;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        UName = findViewById(R.id.username);
        Pass = findViewById(R.id.password);

        Login = findViewById(R.id.login);

        Login.setOnClickListener(View->{
            String Text_UName = UName.getText().toString();
            String Text_Pass = Pass.getText().toString();

            if (Text_UName.equals("Uttam")){
                if (Text_Pass.equals("Uttam")){
                    Intent intent = new Intent(MainActivity.this,Second.class);
                    intent.putExtra("Username",Text_UName);
                    intent.putExtra("Password",Text_Pass);
                    startActivity(intent);
                }else{
                    Toast.makeText(getApplicationContext(), "Invalid Password!", Toast.LENGTH_SHORT).show();
                }
            }else{
                Toast.makeText(getApplicationContext(), "Invalid Username!", Toast.LENGTH_SHORT).show();
            }
        });
    }
}