package com.example.sankalpkadb;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

import java.util.ArrayList;
import java.util.List;

public class mySQLite extends SQLiteOpenHelper {
    private static final String DB_NAME = "sankalp.db";
    private static final int VERSION = 1;
    private static final String TABLE_NAME = "User";
    private static final String COL_NAME = "username";
    private static final String COL_EMAIL = "email";
    private static final String COL_PASS = "password";

    public mySQLite(@Nullable Context context) {
        super(context,
                DB_NAME,
                null,
                VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase) {
        String create_table_query = "create table " + TABLE_NAME + "(" + COL_NAME + " text UNIQUE NOT NULL, " + COL_EMAIL + " text primary key, " + COL_PASS + " text NOT NULL);";
        sqLiteDatabase.execSQL(create_table_query);
    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {
        onCreate(sqLiteDatabase);
    }

    public boolean insertUser(User user){
        SQLiteDatabase sqdb = this.getWritableDatabase();
        ContentValues cv = new ContentValues();

        //add values in cv
        cv.put(COL_NAME, user.getUsername());
        cv.put(COL_EMAIL, user.getEmail().toLowerCase());
        cv.put(COL_PASS, user.getPassword());

        // save cv to sqdb
        long id = sqdb.insert(TABLE_NAME, null, cv);
        sqdb.close();

        return id != -1 ? true : false;
    }

    public boolean createSession(String email, String pass){
        try {
            SQLiteDatabase sqdb = this.getReadableDatabase();
            String search_query = "Select " + COL_PASS + " from " + TABLE_NAME + " WHERE " + COL_EMAIL + "='" + email.toLowerCase() + "';";
            Cursor user_c = sqdb.rawQuery(search_query, null);
            if (user_c.moveToFirst()) {
                System.out.println("mysql> " + user_c.getString(0));
                String hash = user_c.getString(0);
                return (hash.equals(pass) ? true : false);
            }
            return false;
        }catch(Exception err) {
            System.out.println("ERROR> " + err.getMessage());
            return false;
        }
    }

    public List<User> viewAll(){
        SQLiteDatabase sqdb = this.getReadableDatabase();
        String search_query = "Select * from " + TABLE_NAME + ";";
        Cursor lsc = sqdb.rawQuery(search_query, null);
        List<User> ul = new ArrayList<>();
        lsc.moveToFirst();
        do {
            System.out.println("email> " + lsc.getString(0));
            ul.add(new User(lsc.getString(0), lsc.getString(1), lsc.getString(2)));
        } while (lsc.moveToNext());
        return ul;
    }
}
