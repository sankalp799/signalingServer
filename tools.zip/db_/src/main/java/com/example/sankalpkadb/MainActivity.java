package com.example.sankalpkadb;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        EditText email = findViewById(R.id.register_email);
        EditText pass = findViewById(R.id.register_pass);
        EditText username = findViewById(R.id.register_uname);
        Button registerBtn = findViewById(R.id.registerBtn);
        mySQLite user_db = new mySQLite(MainActivity.this);
        Button w_v = findViewById(R.id.webView);

        registerBtn.setOnClickListener(view -> {

            boolean saved = user_db.insertUser(new User(email.getText().toString(), pass.getText().toString(), username.getText().toString()));
            if(!saved){
                Toast.makeText(getApplicationContext(), "Failed to register please try again", Toast.LENGTH_LONG).show();
                return;
            }

            // success
            Intent to_login = new Intent(MainActivity.this, login.class);
            to_login.putExtra("EMAIL_ADDRESS", email.getText().toString());
            startActivity(to_login);
        });

        w_v.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent wvi = new Intent(MainActivity.this, showChicks.class);
                wvi.putExtra("uri", "https://www.google.com");
                startActivity(wvi);
            }
        });
    }
}