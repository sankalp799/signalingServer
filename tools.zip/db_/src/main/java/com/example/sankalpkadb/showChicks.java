package com.example.sankalpkadb;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.webkit.WebView;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import java.util.ArrayList;
import java.util.List;

public class showChicks extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_show_chicks);
        try {
            mySQLite db = new mySQLite(showChicks.this);
            ListView lv = findViewById(R.id.lv1);

            List<User> ul = db.viewAll();
            ArrayAdapter<User> aavl = new ArrayAdapter<User>(showChicks.this, android.R.layout.simple_list_item_1, ul);
            lv.setAdapter(aavl);
        }catch(Exception e){
            System.out.println("ERROR ---> " + e.getMessage());
        }
    }
}