package com.example.sankalpkadb;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class login extends AppCompatActivity {


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        EditText email = (EditText) findViewById(R.id.login_email);
        EditText pass = (EditText) findViewById(R.id.login_pass);
        Button loginBtn = (Button) findViewById(R.id.loginBtn);
        mySQLite db = new mySQLite(login.this);

        Intent reg_i = getIntent();
        email.setText(reg_i.getStringExtra("EMAIL_ADDRESS"));

        loginBtn.setOnClickListener(view -> {
            boolean session = db.createSession(email.getText().toString().toLowerCase(), pass.getText().toString());
            String msg = session ? "Created" : "Invalid Credentials";
            Toast.makeText(getApplicationContext(), msg, Toast.LENGTH_LONG).show();
        });
    }
}