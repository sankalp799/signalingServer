package com.lit.mad_pro;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.EditText;
import android.widget.TextView;

public class Second extends AppCompatActivity {

    TextView Text;
    Intent intent;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_second);

        Text = findViewById(R.id.textView);

        intent = getIntent();

        Text.setText("Username:- "+intent.getStringExtra("Username")+"\nPassword:- "+intent.getStringExtra("Password"));

    }
}