package com.lit.mad_pro;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.MultiAutoCompleteTextView;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    AutoCompleteTextView Auto;
    MultiAutoCompleteTextView MultiAuto;

    String[] Subject = {"MAD","Java","C","C++","PHP","JS","HTML","CSS"};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Auto = findViewById(R.id.auto);
        MultiAuto = findViewById(R.id.multi);

        ArrayAdapter Adapter = new ArrayAdapter(MainActivity.this, android.R.layout.select_dialog_item,Subject);

        Auto.setAdapter(Adapter);
        MultiAuto.setAdapter(Adapter);
        MultiAuto.setThreshold(2);
        MultiAuto.setTokenizer(new MultiAutoCompleteTextView.CommaTokenizer());
    }
}