package com.lit.mad_pro;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {


    EditText Num1, Num2;
    Button Add, Sub, Div, Mul;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Num1 = findViewById(R.id.number1);
        Num2 = findViewById(R.id.number2);

        Add = findViewById(R.id.add);
        Sub = findViewById(R.id.sub);
        Div = findViewById(R.id.div);
        Mul = findViewById(R.id.mul);

        // Add Button
        Add.setOnClickListener(View->{
            int number1 = Integer.parseInt(Num1.getText().toString());
            int number2 = Integer.parseInt(Num2.getText().toString());
            Toast.makeText(getApplicationContext(), "Add :- "+Num1.getText().toString()+" + "+Num2.getText().toString()+" = "+(number1+number2), Toast.LENGTH_SHORT).show();
        });

        // Sub Button
        Sub.setOnClickListener(View->{
            int number1 = Integer.parseInt(Num1.getText().toString());
            int number2 = Integer.parseInt(Num2.getText().toString());
            Toast.makeText(getApplicationContext(), "Sub :- "+Num1.getText().toString()+" - "+Num2.getText().toString()+" = "+(number1-number2), Toast.LENGTH_SHORT).show();
        });


        // Div Button
        Div.setOnClickListener(View->{
            int number1 = Integer.parseInt(Num1.getText().toString());
            int number2 = Integer.parseInt(Num2.getText().toString());
            Toast.makeText(getApplicationContext(), "Div :- "+Num1.getText().toString()+" / "+Num2.getText().toString()+" = "+(number1/number2), Toast.LENGTH_SHORT).show();
        });


        // Mul Button
        Mul.setOnClickListener(View->{
            int number1 = Integer.parseInt(Num1.getText().toString());
            int number2 = Integer.parseInt(Num2.getText().toString());
            Toast.makeText(getApplicationContext(), "Mul :- "+Num1.getText().toString()+" * "+Num2.getText().toString()+" = "+(number1*number2), Toast.LENGTH_SHORT).show();
        });
    }


}