package com.lit.mad_pro;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;

import java.lang.reflect.Array;
import java.util.ArrayList;

public class Second extends AppCompatActivity {

    TextView Name,Mobile,Course,Address;
    Intent intent;
    Button Btn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_second);

        Name = findViewById(R.id.name);
        Mobile = findViewById(R.id.mobile);
        Course = findViewById(R.id.course);
        Address = findViewById(R.id.address);

        Btn = findViewById(R.id.button);

        intent = getIntent();

        Name.setText("Name :- "+intent.getStringExtra("Name"));
        Mobile.setText("Mobile Number :- "+intent.getStringExtra("Mobile"));
        Course.setText("Course Name :- "+intent.getStringExtra("Course"));
        Address.setText("Address :- "+intent.getStringExtra("Address"));

        Btn.setOnClickListener(View->{
            finish();
        });
    }
}