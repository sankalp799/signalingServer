package com.lit.mad_pro;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import java.lang.reflect.Array;
import java.util.ArrayList;

public class Second extends AppCompatActivity {

    ListView List;
    ArrayList<String> arr;
    int size;
    Intent intent;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_second);

        List = findViewById(R.id.listView);

        arr = new ArrayList<String>();

        intent = getIntent();
        size = Integer.parseInt(intent.getStringExtra("Number"));

        for (int i = 0; i < size; i++){
            arr.add("Item - "+i);
        }

        ArrayAdapter adapter = new ArrayAdapter(Second.this, android.R.layout.simple_list_item_1,arr);

        List.setAdapter(adapter);

    }
}