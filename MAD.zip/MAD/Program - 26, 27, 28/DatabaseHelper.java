package com.lit.mad_pro;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class DatabaseHelper extends SQLiteOpenHelper {
    public DatabaseHelper(Context context){
        super(context,"Student_DB",null,1);
    }
    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase) {
        sqLiteDatabase.execSQL("CREATE TABLE Student(Id INTEGER PRIMARY KEY AUTOINCREMENT,Name varchar(50),Course_Name varchar(20),Mobile_Number varchar(10));");
    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {
        sqLiteDatabase.execSQL("DROP TABLE IF EXISTS Student");
        onCreate(sqLiteDatabase);
    }

    public void addData(String Name,String Mobile,String Course){
        SQLiteDatabase sqLiteDatabase = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("Name",Name);
        values.put("Mobile_Number",Mobile);
        values.put("Course_Name",Course);
        sqLiteDatabase.insert("Student",null,values);
    }

    public Cursor getAllData(){
        SQLiteDatabase sqLiteDatabase = this.getWritableDatabase();
        return  sqLiteDatabase.rawQuery("SELECT * FROM Student",null);
    }

    public int updateData(String Id, String Name, String Mobile, String Course){
        SQLiteDatabase sqLiteDatabase = this.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put("Name",Name);
        values.put("Mobile_Number",Mobile);
        values.put("Course_Name",Course);

        return sqLiteDatabase.update("Student",values,"Id = ?",new String[]{Id});
    }
}
