package com.lit.mad_pro;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;

import java.lang.reflect.Array;
import java.util.ArrayList;

public class Second extends AppCompatActivity {

    int size;
    TextView Title;
    ImageView img;
    Intent intent;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_second);

        img = findViewById(R.id.image);
        Title = findViewById(R.id.title);

        intent = getIntent();
        size = Integer.parseInt(intent.getStringExtra("Number"));

        if (size == 0){
            img.setImageResource(R.drawable.img1);
            Title.setText("Image 1 Title");
        }else if(size == 1){
            img.setImageResource(R.drawable.img2);
            Title.setText("Image 2 Title");
        }else {
            img.setImageResource(R.drawable.img3);
            Title.setText("Image 2 Title");
        }

    }
}